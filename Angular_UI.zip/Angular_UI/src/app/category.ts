export class Category {
   id: number;
  categoryName: string;
  categoryDescription: string;

  constructor() {
    this.categoryName = '';
    this.categoryDescription = '';    
  }
}
